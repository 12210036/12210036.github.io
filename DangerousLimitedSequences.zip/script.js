function funtion(x){
  document.getElementById(x).style.display = "none";
}

function fact(x){
  document.getElementById(x).style.display = "block";
}

